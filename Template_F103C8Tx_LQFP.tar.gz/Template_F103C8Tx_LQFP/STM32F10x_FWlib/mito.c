/*
 * mito.c
 *
 *  Created on: Nov 3, 2020
 *      Author: mito
 */

#include "mito.h"

static u8 factor_us = 0; //us延时系数
static u16 factor_ms = 0; //ms延时系数

//初始化延迟函数
//SYSTICK的时钟固定为AHB时钟的1/8
//SysClk_MHz:系统时钟频率
void SysTick_init(u8 SysClk_MHz) {
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8); //系统滴答定时器时钟源配置为 1/8的HCLK
	factor_us = SysClk_MHz / 8;
	factor_ms = (u16) factor_us * 1000;
}

//延时times_us
//times_us为要延时的us数.
void delay_us(u32 times_us) {
	u32 SysTick_CTRL_Value;
	SysTick->LOAD = times_us * factor_us; //时间加载
	SysTick->VAL = 0x00; //清空计数器
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk; //开始倒数
	do {
		SysTick_CTRL_Value = SysTick->CTRL;
	} while ((SysTick_CTRL_Value & 0x01) && !(SysTick_CTRL_Value & (1 << 16)));	//等待时间到达
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;	//关闭计数器
	SysTick->VAL = 0X00;	//清空计数器
}

//延时times_ms
//注意times_ms的范围
//SysTick->LOAD为24位寄存器,所以,最大延时为:
//times_ms<=0xffffff*8*1000/SysClk
//SysClk单位为Hz,times_ms单位为ms
//对72M条件下,times_ms<=1864
void delay_ms(u16 times_ms) {
	u32 SysTick_CTRL_Value;
	SysTick->LOAD = (u32) times_ms * factor_ms;	//时间加载(SysTick->LOAD为24bit)
	SysTick->VAL = 0x00;	//清空计数器
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;	//开始倒数
	do {
		SysTick_CTRL_Value = SysTick->CTRL;
	} while ((SysTick_CTRL_Value & 0x01) && !(SysTick_CTRL_Value & (1 << 16)));	//等待时间到达
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;	//关闭计数器
	SysTick->VAL = 0X00;	//清空计数器
}

//额外的的GPIO模式设定函数
void M_GPIO_Init(GPIO_TypeDef *GPIOx, u16 GPIO_Pin, GPIOSpeed_TypeDef GPIO_Speed, GPIOMode_TypeDef GPIO_Mode) {
	struct M_GPIO2RCC_Struct {
		GPIO_TypeDef *GPIOx;
		u32 RCC_APB2Periph;
	} M_GPIO2RCC_Structure[7] = {	//
			{ GPIOA, RCC_APB2Periph_GPIOA }, {
			GPIOB, RCC_APB2Periph_GPIOB }, {
			GPIOC, RCC_APB2Periph_GPIOC }, {
			GPIOD, RCC_APB2Periph_GPIOD }, {
			GPIOE, RCC_APB2Periph_GPIOE }, {
			GPIOF, RCC_APB2Periph_GPIOF }, {
			GPIOG, RCC_APB2Periph_GPIOG }, };

	//定时器初始化
	for (u8 i = 0; i < 7; i++)
		if (M_GPIO2RCC_Structure[i].GPIOx == GPIOx)
			RCC_APB2PeriphClockCmd(M_GPIO2RCC_Structure[i].RCC_APB2Periph, ENABLE);

	//GPIO初始化
	GPIO_InitTypeDef M_GPIO_InitStructure;
	M_GPIO_InitStructure.GPIO_Pin = GPIO_Pin;
	M_GPIO_InitStructure.GPIO_Mode = GPIO_Mode;
	M_GPIO_InitStructure.GPIO_Speed = GPIO_Speed;

	GPIO_Init(GPIOx, &M_GPIO_InitStructure);
}

//额外的GPIO输出设定函数
void M_GPIO_SetBits(GPIO_TypeDef *GPIOx, u16 GPIO_Pin, bool GPIO_Bit) {
	if (GPIO_Bit == true)
		GPIO_SetBits(GPIOx, GPIO_Pin);
	else
		GPIO_ResetBits(GPIOx, GPIO_Pin);
}

//额外的GPIO输出翻转函数
void M_GPIO_Flip(GPIO_TypeDef *GPIOx, u16 GPIO_Pin) {
	uint8_t M_GPIO_OutputDataBit = GPIO_ReadOutputDataBit(GPIOx, GPIO_Pin);
	if (M_GPIO_OutputDataBit == 1)
		GPIO_ResetBits(GPIOx, GPIO_Pin);
	else
		GPIO_SetBits(GPIOx, GPIO_Pin);
}

//基于结构体的GPIO模式设定函数
void MS_GPIO_Init(M_GPIO_InitTypeDef *M_GPIO) {
	M_GPIO_Init(M_GPIO->GPIOx, M_GPIO->GPIO_Pin, M_GPIO->GPIO_Speed, M_GPIO->GPIO_Mode);
}

//基于结构体的GPIO输出函数
void MS_GPIO_SetBits(M_GPIO_InitTypeDef *M_GPIO, bool GPIO_Bit) {
	M_GPIO_SetBits(M_GPIO->GPIOx, M_GPIO->GPIO_Pin, GPIO_Bit);
}

//基于结构体的GPIO输出翻转函数
void MS_GPIO_Flip(M_GPIO_InitTypeDef *M_GPIO) {
	M_GPIO_Flip(M_GPIO->GPIOx, M_GPIO->GPIO_Pin);
}

