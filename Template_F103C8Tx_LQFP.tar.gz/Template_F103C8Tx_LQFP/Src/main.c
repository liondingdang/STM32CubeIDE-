#include "stm32f10x.h"
#include "mito.h"

int main() {
    SysTick_init(72); //初始化滴答定时器以初始化延时
    M_GPIO_Init(GPIOC, GPIO_Pin_13, GPIO_Speed_50MHz, GPIO_Mode_Out_PP);
    while (1) {
        M_GPIO_Flip(GPIOC, GPIO_Pin_13);
        delay_ms(1000);
    }

    return 0;
}
