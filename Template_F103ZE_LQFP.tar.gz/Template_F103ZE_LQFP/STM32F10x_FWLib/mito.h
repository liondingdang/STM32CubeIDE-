/*
 * mito.h
 *
 *  Created on: Nov 3, 2020
 *      Author: mito
 */

#ifndef MITO_H_
#define MITO_H_

#include <stm32f10x.h>

//提供位带操作支持

//IO口操作宏定义
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2))
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr))
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum))
//IO口地址映射
#define GPIOA_ODR_Addr    (GPIOA_BASE+12) //0x4001080C
#define GPIOB_ODR_Addr    (GPIOB_BASE+12) //0x40010C0C
#define GPIOC_ODR_Addr    (GPIOC_BASE+12) //0x4001100C
#define GPIOD_ODR_Addr    (GPIOD_BASE+12) //0x4001140C
#define GPIOE_ODR_Addr    (GPIOE_BASE+12) //0x4001180C
#define GPIOF_ODR_Addr    (GPIOF_BASE+12) //0x40011A0C
#define GPIOG_ODR_Addr    (GPIOG_BASE+12) //0x40011E0C

#define GPIOA_IDR_Addr    (GPIOA_BASE+8) //0x40010808
#define GPIOB_IDR_Addr    (GPIOB_BASE+8) //0x40010C08
#define GPIOC_IDR_Addr    (GPIOC_BASE+8) //0x40011008
#define GPIOD_IDR_Addr    (GPIOD_BASE+8) //0x40011408
#define GPIOE_IDR_Addr    (GPIOE_BASE+8) //0x40011808
#define GPIOF_IDR_Addr    (GPIOF_BASE+8) //0x40011A08
#define GPIOG_IDR_Addr    (GPIOG_BASE+8) //0x40011E08

//IO口操作,只对单一的IO口进行操作,0<=n<=15
#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr,n)  //输出
#define PAin(n)    BIT_ADDR(GPIOA_IDR_Addr,n)  //输入

#define PBout(n)   BIT_ADDR(GPIOB_ODR_Addr,n)  //输出
#define PBin(n)    BIT_ADDR(GPIOB_IDR_Addr,n)  //输入

#define PCout(n)   BIT_ADDR(GPIOC_ODR_Addr,n)  //输出
#define PCin(n)    BIT_ADDR(GPIOC_IDR_Addr,n)  //输入

#define PDout(n)   BIT_ADDR(GPIOD_ODR_Addr,n)  //输出
#define PDin(n)    BIT_ADDR(GPIOD_IDR_Addr,n)  //输入

#define PEout(n)   BIT_ADDR(GPIOE_ODR_Addr,n)  //输出
#define PEin(n)    BIT_ADDR(GPIOE_IDR_Addr,n)  //输入

#define PFout(n)   BIT_ADDR(GPIOF_ODR_Addr,n)  //输出
#define PFin(n)    BIT_ADDR(GPIOF_IDR_Addr,n)  //输入

#define PGout(n)   BIT_ADDR(GPIOG_ODR_Addr,n)  //输出
#define PGin(n)    BIT_ADDR(GPIOG_IDR_Addr,n)  //输入

//提供布尔类型（伪）
typedef enum {
	true = 1, false = 0
} boolean;

//提供GPIO地址结构体
typedef struct {
	GPIO_TypeDef *GPIOx;
	uint16_t GPIO_Pin;
} M_GPIO_AddressStruct;

//提供IO口对应各种寄存器
typedef struct {

}M_GPIO_REG;

//对外接口
void SysTick_init(u8 SysClk_MHz); //系统滴答定时器初始化
void delay_us(u32 times_us); //微秒级延时
void delay_ms(u16 times_ms); //毫秒级延时

//额外的函数
void M_GPIO_Init(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin, GPIOSpeed_TypeDef GPIO_Speed, GPIOMode_TypeDef GPIO_Mode); //额外的的GPIO模式设定函数
void M_GPIO_SetBits(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin, boolean GPIO_Bit); //额外的GPIO输出设定函数
void M_GPIO_Flip(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin); //额外的GPIO输出翻转函数

void M_TIM_TimeBase_Init(TIM_TypeDef *TIMx, uint16_t TIM_ClockDivision, uint16_t TIM_CounterMode, uint16_t TIM_Period,
		uint16_t TIM_Prescaler, uint8_t TIM_RepetitionCounter); //额外的定时器时基初始化函数

#endif /* MITO_H_ */
