#include "stm32f10x.h"
#include "mito.h"

int main(void) {
    SysTick_init(72); //初始化定时器

    return 0;
}
